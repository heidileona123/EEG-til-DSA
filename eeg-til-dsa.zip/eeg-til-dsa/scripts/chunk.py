import sys, subprocess, asyncio
from playwright.async_api import async_playwright
import os
BASE=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
FPS=25
async def main(a,b,out):
    ff = subprocess.Popen(['ffmpeg','-v','error','-y','-f','image2pipe','-framerate',str(FPS),'-i','-','-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart',out],stdin=subprocess.PIPE)
    async with async_playwright() as p:
        br = await p.chromium.launch(executable_path='/opt/pw-browsers/chromium', args=['--allow-file-access-from-files'])
        pg = await br.new_page(viewport={'width':1920,'height':1080})
        pg.on('pageerror', lambda e: print('ERR', e, flush=True))
        await pg.goto('file://'+BASE+'/index.html?render')
        await pg.wait_for_function('window.ready===true', timeout=30000)
        c = pg.locator('#c')
        for f in range(a,b):
            await pg.evaluate(f'drawFrame({f/FPS})')
            ff.stdin.write(await c.screenshot(type='png'))
        await br.close()
    ff.stdin.close(); ff.wait()
    print('done',a,b,flush=True)
a,b=int(sys.argv[1]),int(sys.argv[2])
asyncio.run(main(a,b,sys.argv[3]))
