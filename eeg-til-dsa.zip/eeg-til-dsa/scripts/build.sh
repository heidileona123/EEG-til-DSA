#!/bin/sh
# Renderer hele videoen (90 s, 25 fps, 1080p) i seks biter og setter dem sammen.
# Krever: python3 + playwright (med Chromium), ffmpeg.
set -e
cd "$(dirname "$0")/.."
mkdir -p chunks
for i in 0 1 2 3 4 5; do echo "$((i*375)) $(((i+1)*375)) chunks/c$i.mp4"; done | xargs -P2 -L1 python3 scripts/chunk.py
for i in 0 1 2 3 4 5; do echo "file 'chunks/c$i.mp4'"; done > chunks/list.txt
ffmpeg -y -f concat -safe 0 -i chunks/list.txt -c copy -movflags +faststart EEG_til_DSA_norsk_hvit.mp4
